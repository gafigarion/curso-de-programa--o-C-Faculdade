#include <stdio.h>
#include <stdlib.h>

int main()
{
  int qtdias,dias,anos,meses;
  
  printf("favor digite quantidade de dias:\n ");
  scanf("%d",&qtdias);
  
  if (dias>0){
     anos = qtdias/365;
     qtdias = qtdias - (365 * anos );
     
     meses = qtdias/30;
     qtdias = qtdias - (30 * meses);
     
     dias = qtdias;  
     
     printf ("\n %d ano(s) %d mese(s) e %d dia(s) ", anos,meses,dias);          
  }
  else{
        printf("numero invalido");     
  }
  getch();	
  return 0;
}
