#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{  
  int numero;
  float resultado;
  
  printf("digite um numero inteiro:\n ");
  scanf("%d",&numero);
  
  if (numero>0){
     resultado = sqrt(numero);
     printf("raiz quadrada do numero digitado e: %f",resultado);
  }else{
        resultado = numero * numero;
        printf("o quadrado do numero digitado e: %f: ", resultado);      
  }
  
  getch();	
  return 0;
}
