#include <stdio.h>
#include <stdlib.h>

int main()
{
  int i,numero,soma;
  soma = 0;
  
  printf("digite um numero: ");
  scanf("%d",&numero);
  
  for (i=numero ; i>= 1 ; i--){
      numero = numero - 1;    
      soma = soma + numero;
  }
  
  printf("resultado e: %d", soma);
  
  getch();	
  return 0;
}
