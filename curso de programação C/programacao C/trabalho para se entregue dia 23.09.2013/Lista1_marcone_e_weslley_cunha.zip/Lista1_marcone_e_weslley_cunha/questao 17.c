#include <stdio.h>
#include <stdlib.h>

   
int main()
{

  int termo1, termo2, termo3, i, numero;
  termo1 = 0;
  termo2 = 1;
  termo3 = 0;
 

  printf("Digite um numero: ");
  scanf("%d", &numero);
  printf("Sequencia de Fibonacci:\n");
  printf("%d\n", termo2);

  for(i = 0; termo3 < numero; i++){
    termo3 = termo1 + termo2;
    termo1 = termo2;
    termo2 = termo3;
    printf("%d\n",termo3);
  }


  
  getch();	
  return 0;
}
