#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
  
  float pv,i,n;/*presente valor,taxa,periodo*/
  double pmt;/*valor da prestacao*/
  
  printf("digite o valor inicial em reais:\n");
  scanf("%f",&pv);
  printf("digite o periodo em meses:\n");
  scanf("%f",&n);
  printf("digite a taxa de juros:\n");
  scanf("%f",&i);
  
  pmt = pv * ((pow(1+(i/100),n) * (i/100)) / (pow(1+(i/100),n)-1)) ;
  
  printf("resulatdo e: %f",pmt);
  
  getch();	
  return 0;
}

/* pmt = pv * (1+i/100)^n / (1+i/100)^n -1*/
