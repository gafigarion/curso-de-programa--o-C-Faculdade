#include <stdio.h>
#include <stdlib.h>

int main()
{
  
  float fv,pv,i,n;/*futuro valor,presente valor,taxa,periodo*/
  
  printf("digite o valor inicial em reais:\n");
  scanf("%f",&pv);
  printf("digite o periodo em meses:\n");
  scanf("%f",&n);
  printf("digite a taxa de juros:\n");
  scanf("%f",&i);
  
  fv = pv * (1 + (i/100) * n);
  
  printf("resulatdo e: %f",fv);
  
  getch();	
  return 0;
}
