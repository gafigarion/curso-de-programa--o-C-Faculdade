#include <stdio.h>
#include <stdlib.h>

int ler(int x){
    printf("Digite um numero:\n");
    scanf("%d",&x); 
    return (x); 
}

int main()
{
  
  int numero;
  int i;
  
  numero = ler(numero);
  
  for ( i=numero ; i>0 ; i--){
      numero = numero - 1;
      if (numero % 2 == 0 && numero < i && numero % 4 == 0 && numero != 0){
         printf("%d\n",numero);  
      }else{
            continue;
      }  
  }

  
  
  
  
  getch();	
  return 0;
}
