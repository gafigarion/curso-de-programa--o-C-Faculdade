#include <stdio.h>
#include <stdlib.h>

int ler1(){
    int a;
    scanf("%d",&a);
    return (a);
}     

int ler2(){
    int b;
    scanf("%d",&b);
    return (b);
}     

void ordem(int a,int b){
     int aux;
     if (a<b){
        printf("ordem crescente e: %d %d", a, b);
     }else{
           aux = a;
           a = b;
           b = aux;
           printf("ordem crescente e: %d %d", a,b);
     }     
}


int main()
{
  int n1,n2;
  
  printf("digite 2 numeros:\n");
  n1 = ler1();
  n2 = ler2();
  ordem(n1,n2);
  
  
  getch();	
  return 0;
}
