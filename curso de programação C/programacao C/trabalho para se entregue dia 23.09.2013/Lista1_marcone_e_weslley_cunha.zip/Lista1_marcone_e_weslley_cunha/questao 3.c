#include <stdio.h>
#include <stdlib.h>

float Media(float a,float b){
      float media;
      media = (a + b)/2;
      return (media);  
}


int main()
{
  float nota1,nota2,media;
  
  printf("digite a primeira nota:\n ");
  scanf("%f",&nota1);
  printf("digite a segunda nota:\n ");
  scanf("%f",&nota2);
  
  media = Media(nota1,nota2);
  if (media>=7){
     printf("aluno aprovada!!! media foi: %f ",media);
  }else{
        printf("aluno reprovado!!! media foi: %f",media);
  }
  
  getch();
  return 0;
}
