#include <stdio.h>
#include <stdlib.h>

float ler1(float a){
      scanf("%f",&a);
      return (a);
}

float ler2(float b){
      scanf("%f",&b);
      return (b);
}

float calculo (float a,float b){
      float result;
      result = ( a * a ) + ( b * b );
      return (result);
}



int main()
{
  
  float n1,n2,resultado;
  
  printf("digite dois numeros:\n");
  n1 = ler1(n1);
  n2 = ler2(n2);
  resultado = calculo(n1,n2);
  printf("resultado e: %f", resultado);
  
  
 
  
  getch();	
  return 0;
}
