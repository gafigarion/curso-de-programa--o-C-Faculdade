#include <stdio.h>
#include <stdlib.h>

int main()
{
  
  float valores [4],soma;
  int i;
  
  printf("digite 5 numeros:\n");
  for (i=0;i<=4;i++){
     scanf("%f",&valores[i]);   
     soma = soma + valores[i];
  }
  
  soma = soma * 1.1;
  printf("resultado e:%f\n ",soma);
  

  
  getch();	
  return 0;
}
