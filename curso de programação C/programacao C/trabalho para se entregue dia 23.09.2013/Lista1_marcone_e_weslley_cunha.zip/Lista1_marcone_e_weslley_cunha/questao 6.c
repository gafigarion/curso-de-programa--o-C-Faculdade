#include <stdio.h>
#include <stdlib.h>

float dist(float a,float b){
      float result;
      result = a * b; //* distancia = velocidade * tempo *//
      return (result);    
}

int main()
{
  
  float t,v,d,resultado;
  
  printf("digite velocidade media do veiculo em km/h:\n ");
  scanf("%f",&v);
  printf("digite tempo gasto na viagem em horas:\n ");
  scanf("%f",&t);
  
  resultado = dist(v,t);
  resultado = resultado/12;
  
  printf("quantidade de combustivel gasto em litros foi: %f\n",resultado );
  
  getch();	
  return 0;
}
