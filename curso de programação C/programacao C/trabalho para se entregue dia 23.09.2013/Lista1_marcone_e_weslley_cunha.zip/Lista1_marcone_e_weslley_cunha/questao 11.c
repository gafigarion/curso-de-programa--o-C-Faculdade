#include <stdio.h>
#include <stdlib.h>

void reconhecer(float a,float b,float c){
     if ( a>b+c  || b>a+c || c>a+b ){
       printf("figura formada nao e um triangulo.");
    }else{
          printf("figura formada e um triangulo.");
        
    }
}


int main()
{
  float x,y,z;
  
  printf("favor inserir 3 numeros:\n");
  scanf("%f",&x);
  scanf("%f",&y);
  scanf("%f",&z);
  reconhecer(x,y,z);


  
  
  getch();	
  return 0;
}
