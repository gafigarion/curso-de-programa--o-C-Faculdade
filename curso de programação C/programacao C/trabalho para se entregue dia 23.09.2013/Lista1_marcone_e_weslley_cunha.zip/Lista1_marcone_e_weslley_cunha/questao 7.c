#include <stdio.h>
#include <stdlib.h>

int main()
{
  
  float alcool,gasolina,resultado;
  printf("digite valor do alcool:\n ");
  scanf("%f",&alcool);
  printf("digite valor da gasolina:\n ");
  scanf("%f",&gasolina);
  
  if (alcool || gasolina != 0){
  
     resultado = gasolina * 0.3;
     if (resultado>=alcool){
        printf("abastecer com alcool e mais vantajoso: ");                       
     }else{
           printf("abastecer com gasolina e mais vantajoso: ");
     }
  
  }else{
        printf("valores invalidos!!! favor inserir valores diferentes de 0.\n");
  }
  
  getch();	
  return 0;
}
