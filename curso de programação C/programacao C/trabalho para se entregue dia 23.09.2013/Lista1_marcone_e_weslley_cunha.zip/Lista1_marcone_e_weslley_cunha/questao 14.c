#include <stdio.h>
#include <stdlib.h>

int ler(int a){
    scanf("%d",&a);
    return (a);    
}

void descobrirmenor(int a){
     int i;
     printf("numeros antecessores sao:\n");
     for (i=0;i<=9;i++){
         a = a - 1;
         printf("%d\n",a);
     }        
}


void descobrirmaior(int a){
     int i;
     printf("numeros sucessores sao:\n");
     for (i=0;i<=9;i++){
         a = a + 1;
         printf("%d\n",a);
     }        
}


int main()
{
  int numero;
  
  printf("digite um numer:\n");
  numero = ler(numero);
  descobrirmaior(numero);
  descobrirmenor(numero);

  
  
  getch();	
  return 0;
}
