#include <stdio.h>
#include <stdlib.h>

int main()
{
  int numero,antecessor,sucessor;
  
  printf("digite um numero:\n ");
  scanf("%d",&numero);
  
  antecessor = numero - 1;
  sucessor = numero + 1;
  
  printf("numero antecessor e: %d\n ",antecessor);
  printf("numero sucessor e: %d\n ",sucessor);
  
  
  
  getch();	
  return 0;
}
