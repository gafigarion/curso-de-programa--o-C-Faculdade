#include <stdio.h>
#include <stdlib.h>

int main()
{
  int numero;
  
  printf("digite um numero:\n");
  scanf("%d",&numero);
  
  if(numero % 2 == 0)
            printf("numero e par!!!");
  else
      printf("numero e impar!!!");
  
  getch();	
  return 0;
}
