#include <stdio.h>
#include <stdlib.h>

float ler(float num){
      printf("digite um valor em grau Celsius:\n ");
      scanf("%f",&num);
      return (num);      
}

float converter(float c){
      float result;
      result = (c * 1.8) + 32;
      return (result);    
}

int main()
{
  float f,c;
  
  c = ler(c);
  f = converter(c);
  printf("resultado da conversao para Fahrenheit e: %f\n ", f);
 
  getch();	
  return 0;
}
